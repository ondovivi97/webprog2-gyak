exports.index = (req, res) => {
    res.send("Főoldal működik!");
};
